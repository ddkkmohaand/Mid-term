import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowDown, ArrowRight, ArrowUpRight, Menu, X } from 'lucide-react'
import Watch3D from './components/Watch3D'

type Model = { id: 'gold' | 'black' | 'silver'; name: string; edition: string; description: string; price: string; material: string; movement: string; resistance: string }
const models: Model[] = [
  { id: 'gold', name: 'ROYAL', edition: '01 / GOLD EDITION', description: 'A confident expression of timeless prestige, finished in warm champagne gold.', price: 'AED 18,900', material: '18K champagne gold finish', movement: 'Automatic calibre', resistance: '100 metres' },
  { id: 'black', name: 'PHANTOM', edition: '02 / BLACK EDITION', description: 'A study in restraint. Deep graphite tones meet a striking architectural silhouette.', price: 'AED 16,500', material: 'Black PVD stainless steel', movement: 'Automatic calibre', resistance: '100 metres' },
  { id: 'silver', name: 'TITANIUM', edition: '03 / SILVER EDITION', description: 'Lightweight strength and precision detailing, engineered for everyday distinction.', price: 'AED 17,200', material: 'Brushed titanium finish', movement: 'Automatic calibre', resistance: '100 metres' },
]

function App() {
  const [active, setActive] = useState<Model>(models[0])
  const [menuOpen, setMenuOpen] = useState(false)
  const [detailsOpen, setDetailsOpen] = useState(false)

  const goTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
    setMenuOpen(false)
  }

  return (
    <main>
      <div className="topline"><span>INDEPENDENT WATCHMAKING</span><span>GENEVA · SWITZERLAND</span><span>EST. MMXXIV</span></div>
      <header className="nav">
        <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? 'nav-links nav-links--open' : 'nav-links'}>
          <button onClick={() => goTo('collection')}>COLLECTION</button>
          <button onClick={() => goTo('craft')}>CRAFTSMANSHIP</button>
        </nav>
        <a className="wordmark" href="#home" onClick={() => setMenuOpen(false)}>CHRONOVA<span>✳</span></a>
        <div className="nav-right"><button onClick={() => goTo('details')}>THE WATCH</button><button className="inquire" onClick={() => goTo('contact')}>INQUIRE <ArrowUpRight size={13} /></button></div>
      </header>

      <section className="hero" id="home">
        <div className="hero-grain" />
        <div className="hero-copy">
          <motion.p initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="eyebrow">THE ART OF EVERY SECOND</motion.p>
          <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>TIME,<br /><em>REDEFINED.</em></motion.h1>
          <motion.p className="hero-sub" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }}>Precision engineered.<br />Timeless by design.</motion.p>
          <motion.button className="line-button" onClick={() => goTo('collection')} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }}>DISCOVER THE COLLECTION <ArrowRight size={15} /></motion.button>
        </div>
        <div className="hero-watch"><Watch3D finish={active.id} /></div>
        <div className="hero-index"><span>01</span><i /> <span>03</span></div>
        <div className="hero-bottom"><span>SCULPTED FOR THE MOMENT</span><button onClick={() => goTo('collection')}>SCROLL TO DISCOVER <ArrowDown size={13} /></button><span>SWISS INSPIRED · WORLD MADE</span></div>
      </section>

      <section className="intro section-pad">
        <p className="eyebrow">A DIFFERENT PERSPECTIVE ON TIME</p>
        <h2>Not simply measured.<br /><em>Meaningfully made.</em></h2>
        <p className="intro-text">A CHRONOVA timepiece is an invitation to slow down, look closer, and appreciate the extraordinary detail behind every passing second.</p>
        <div className="intro-rule"><span>01 — THE PHILOSOPHY</span><span>DESIGNED TO ENDURE</span></div>
      </section>

      <section className="collection section-pad" id="collection">
        <div className="section-heading"><div><p className="eyebrow">THE CHRONOVA COLLECTION</p><h2>Three expressions.<br /><em>One standard.</em></h2></div><p className="section-note">Explore the collection and interact<br />with each timepiece in three dimensions.</p></div>
        <div className="collection-layout">
          <div className="model-list">
            {models.map((model, i) => (
              <button className={`model-row ${active.id === model.id ? 'selected' : ''}`} key={model.id} onClick={() => setActive(model)}>
                <span className="model-number">0{i + 1}</span><span className="model-name">{model.name}<small>{model.edition}</small></span><ArrowUpRight className="model-arrow" size={17} />
              </button>
            ))}
            <div className="model-description"><p>{active.description}</p><span>{active.price}</span></div>
          </div>
          <div className="collection-viewer"><div className="viewer-glow" /><Watch3D finish={active.id} compact /><span className="viewer-caption">INTERACTIVE 3D VIEWER <i /> {active.name}</span></div>
        </div>
      </section>

      <section className="details section-pad" id="details">
        <div className="details-top"><p className="eyebrow">THE OBJECT, CONSIDERED</p><span>REF. CHR — {active.id === 'gold' ? '001' : active.id === 'black' ? '002' : '003'}</span></div>
        <div className="details-main">
          <div><h2>Designed with<br /><em>intention.</em></h2><p className="details-copy">Every line has a purpose. Every surface has a story. Discover the considered details that make {active.name.toLowerCase()} unmistakably CHRONOVA.</p><button className="line-button" onClick={() => setDetailsOpen(!detailsOpen)}>{detailsOpen ? 'HIDE SPECIFICATIONS' : 'EXPLORE SPECIFICATIONS'} <ArrowRight size={15} /></button></div>
          <div className="specs">
            <div><span>CASE MATERIAL</span><strong>{active.material}</strong></div>
            <div><span>MOVEMENT</span><strong>{active.movement}</strong></div>
            <div><span>WATER RESISTANCE</span><strong>{active.resistance}</strong></div>
            <div><span>CASE DIAMETER</span><strong>41.5 mm</strong></div>
            {detailsOpen && <div className="extra-spec"><span>CRYSTAL</span><strong>Sapphire crystal with anti-reflective coating</strong></div>}
            {detailsOpen && <div className="extra-spec"><span>POWER RESERVE</span><strong>Approximately 42 hours</strong></div>}
          </div>
        </div>
      </section>

      <section className="craft" id="craft">
        <div className="craft-image"><div className="craft-orbit orbit-one" /><div className="craft-orbit orbit-two" /><div className="craft-emblem">C<span>✳</span></div><span className="image-label">FORM FOLLOWS FUNCTION</span></div>
        <div className="craft-copy"><p className="eyebrow">THE PURSUIT OF PRECISION</p><h2>Craft is not<br />a detail. <em>It is<br />the difference.</em></h2><p>From the first sketch to the final polish, every CHRONOVA timepiece is shaped by a belief that excellence lives in the details you notice — and the ones you don't.</p><button className="line-button" onClick={() => goTo('contact')}>OUR PHILOSOPHY <ArrowRight size={15} /></button><span className="craft-count">02 / THE CRAFT</span></div>
      </section>

      <section className="manifesto section-pad"><p className="eyebrow">A MOMENT, MADE YOURS</p><h2>Make every second<br /><em>count for something.</em></h2><button className="gold-button" onClick={() => goTo('contact')}>ENQUIRE ABOUT CHRONOVA <ArrowUpRight size={15} /></button></section>

      <footer id="contact">
        <div className="footer-top"><div><a className="wordmark footer-logo" href="#home">CHRONOVA<span>✳</span></a><p>TIME, REDEFINED.</p></div><div className="footer-links"><button onClick={() => goTo('collection')}>COLLECTION</button><button onClick={() => goTo('craft')}>OUR CRAFT</button><a href="mailto:concierge@chronova.example">CONTACT CONCIERGE</a></div><div className="footer-contact"><span>PRIVATE ENQUIRIES</span><a href="mailto:concierge@chronova.example">concierge@chronova.example</a><span>GENEVA · SWITZERLAND</span></div></div>
        <div className="footer-bottom"><span>© 2026 CHRONOVA. ALL RIGHTS RESERVED.</span><span>TIME, REDEFINED.</span><a href="#home">BACK TO TOP ↑</a></div>
      </footer>
    </main>
  )
}
export default App