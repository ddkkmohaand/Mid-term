import { Suspense, useMemo, useRef } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { ContactShadows, Environment, OrbitControls, Sparkles } from '@react-three/drei'
import * as THREE from 'three'

type WatchProps = { finish?: 'gold' | 'black' | 'silver'; compact?: boolean }

function WatchModel({ finish = 'gold' }: WatchProps) {
  const group = useRef<THREE.Group>(null)
  const second = useRef<THREE.Mesh>(null)
  const palette = useMemo(() => ({
    gold: { metal: '#bd9655', edge: '#e4c98e', dial: '#101214', strap: '#4c3524' },
    black: { metal: '#34383b', edge: '#777d80', dial: '#080a0c', strap: '#17191b' },
    silver: { metal: '#aeb5b9', edge: '#edf0ed', dial: '#151a1d', strap: '#343a3d' },
  })[finish], [finish])

  useFrame((state, delta) => {
    if (group.current) {
      group.current.rotation.y += delta * 0.12
      group.current.rotation.x = THREE.MathUtils.lerp(group.current.rotation.x, -0.12 + Math.sin(state.clock.elapsedTime * 0.35) * 0.025, 0.025)
    }
    if (second.current) second.current.rotation.z -= delta * 0.65
  })

  const markers = Array.from({ length: 12 }, (_, i) => {
    const a = (i / 12) * Math.PI * 2
    return [Math.sin(a) * 1.02, Math.cos(a) * 1.02] as [number, number]
  })

  return (
    <group ref={group} rotation={[0.1, 0, -0.08]} scale={0.92}>
      {/* integrated bracelet / strap */}
      <mesh position={[0, 1.75, -0.08]} rotation={[0.18, 0, 0]}>
        <boxGeometry args={[0.72, 2.15, 0.19]} />
        <meshStandardMaterial color={palette.strap} metalness={finish === 'gold' ? 0.38 : 0.22} roughness={0.36} />
      </mesh>
      <mesh position={[0, -1.75, -0.08]} rotation={[-0.18, 0, 0]}>
        <boxGeometry args={[0.72, 2.15, 0.19]} />
        <meshStandardMaterial color={palette.strap} metalness={finish === 'gold' ? 0.38 : 0.22} roughness={0.36} />
      </mesh>
      {/* polished case and bezel */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[1.34, 1.34, 0.34, 96]} />
        <meshStandardMaterial color={palette.metal} metalness={0.9} roughness={0.2} />
      </mesh>
      <mesh position={[0, 0, 0.2]}>
        <cylinderGeometry args={[1.23, 1.23, 0.11, 96]} />
        <meshStandardMaterial color={palette.edge} metalness={0.95} roughness={0.16} />
      </mesh>
      <mesh position={[0, 0, 0.27]}>
        <cylinderGeometry args={[1.14, 1.14, 0.08, 96]} />
        <meshStandardMaterial color={palette.dial} metalness={0.38} roughness={0.28} />
      </mesh>
      {/* dial details */}
      <mesh position={[0, 0, 0.32]}>
        <torusGeometry args={[1.08, 0.018, 8, 100]} />
        <meshStandardMaterial color={palette.edge} metalness={0.9} roughness={0.22} />
      </mesh>
      {markers.map(([x, y], i) => (
        <mesh key={i} position={[x, y, 0.36]} rotation={[0, 0, -Math.atan2(x, y)]}>
          <boxGeometry args={[i % 3 === 0 ? 0.045 : 0.025, i % 3 === 0 ? 0.16 : 0.09, 0.025]} />
          <meshStandardMaterial color={palette.edge} metalness={0.85} roughness={0.22} />
        </mesh>
      ))}
      {/* central pin */}
      <mesh position={[0, 0, 0.43]}>
        <cylinderGeometry args={[0.07, 0.07, 0.06, 24]} />
        <meshStandardMaterial color={palette.edge} metalness={1} roughness={0.12} />
      </mesh>
      {/* hands */}
      <mesh position={[-0.12, 0.12, 0.405]} rotation={[0, 0, 0.65]}>
        <boxGeometry args={[0.055, 0.62, 0.018]} />
        <meshStandardMaterial color={palette.edge} metalness={0.9} roughness={0.2} />
      </mesh>
      <mesh position={[0.18, -0.02, 0.42]} rotation={[0, 0, -0.95]}>
        <boxGeometry args={[0.035, 0.86, 0.014]} />
        <meshStandardMaterial color={palette.edge} metalness={0.9} roughness={0.2} />
      </mesh>
      <mesh ref={second} position={[0, 0, 0.455]}>
        <boxGeometry args={[0.014, 0.96, 0.012]} />
        <meshStandardMaterial color="#c66b4a" metalness={0.5} roughness={0.3} />
      </mesh>
      {/* crown and crown guards */}
      <mesh position={[1.42, 0, 0]} rotation={[Math.PI / 2, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.16, 0.16, 0.28, 32]} />
        <meshStandardMaterial color={palette.metal} metalness={0.95} roughness={0.2} />
      </mesh>
      {[-0.27, 0.27].map((y) => (
        <mesh key={y} position={[1.31, y, 0]}>
          <boxGeometry args={[0.18, 0.12, 0.23]} />
          <meshStandardMaterial color={palette.metal} metalness={0.9} roughness={0.22} />
        </mesh>
      ))}
      {/* glass highlight */}
      <mesh position={[0, 0, 0.49]}>
        <cylinderGeometry args={[1.12, 1.12, 0.018, 96]} />
        <meshPhysicalMaterial color="#dce5e8" transparent opacity={0.075} roughness={0.05} metalness={0} clearcoat={1} />
      </mesh>
      <mesh position={[0, 0, 0.505]}>
        <torusGeometry args={[1.13, 0.012, 8, 100]} />
        <meshStandardMaterial color="#ffffff" metalness={0.8} roughness={0.12} />
      </mesh>
    </group>
  )
}

export default function Watch3D({ finish = 'gold', compact = false }: WatchProps) {
  return (
    <div className={`watch-canvas ${compact ? 'watch-canvas--compact' : ''}`}>
      <Canvas camera={{ position: [0, 0, 6.8], fov: 34 }} dpr={[1, 1.7]} gl={{ antialias: true, alpha: true }}>
        <Suspense fallback={null}>
          <ambientLight intensity={1.1} />
          <spotLight position={[4, 6, 7]} intensity={95} angle={0.45} penumbra={1} />
          <pointLight position={[-5, -2, 4]} intensity={28} color="#b58d56" />
          <Environment preset="studio" />
          <WatchModel finish={finish} />
          {!compact && <Sparkles count={24} scale={5} size={1.2} speed={0.18} opacity={0.3} color="#d8bb83" />}
          <ContactShadows position={[0, -2.85, 0]} opacity={0.35} scale={7} blur={2.5} far={4} />
          <OrbitControls enablePan={false} enableZoom minDistance={4.8} maxDistance={9.5} rotateSpeed={0.65} zoomSpeed={0.7} />
        </Suspense>
      </Canvas>
      <span className="drag-hint">DRAG TO EXPLORE · SCROLL TO ZOOM</span>
    </div>
  )
}