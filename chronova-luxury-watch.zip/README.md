# CHRONOVA — Luxury 3D Watch Experience

A responsive luxury watch landing page built with React, TypeScript, Three.js, React Three Fiber, Drei, Framer Motion, and Tailwind CSS.

## Run locally

Requirements: Node.js 18.18+ (Node 20 LTS recommended).

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Production build

```bash
npm run build
npm run preview
```

The production site is generated in `dist/`.

## Features

- Procedurally modelled 3D watch built from Three.js geometry — no external 3D model required.
- Drag to rotate and scroll/pinch to zoom using OrbitControls.
- Three selectable finishes: Royal Gold, Phantom Black, and Titanium Silver.
- Responsive layout for desktop, tablet, and mobile.
- Smooth entrance animations and section navigation.
- Product specification reveal interaction.
- Contact links use a placeholder `.example` address; replace it with your real concierge email before publishing.

## Notes

The watch is a stylized procedural 3D concept model, not a manufacturing-accurate CAD asset. Product names, prices, movement details, and specifications are illustrative placeholders and should be verified or replaced before commercial use.

The project uses remote Google Fonts. A local system-font fallback is included if the font service is unavailable.
